// C15 FIX2 private Shared Utilities 4.1 script replacement. Compile from matched game+REDkit source; NEVER install loose.
// CR01 LIFECYCLE01 integrated event transport + native disabled-row lifecycle.
// Patch 5.01 + Shared Utilities 4.1. Compile ONLY via the proven wcc_lite patch
// workflow into precompiled.rsblob. Never install this source loosely.
//
// UI policy:
//   Master Off -> all 15 dependent controls disabled=true.
//   Master On  -> all 15 dependent controls disabled=false.
// Renderer eligibility remains native/ASI-side and never greys PT preferences.
//
// Event transport:
//   The genuine OnOptionValueChanged event writes the config first. CR01 then
//   explicitly saves user settings only for CR01 values and renderer-mode/
//   native-shadow values that the lifecycle owner needs to observe. The ASI
//   consumes the resulting exact file-change event and diffs CR01 values.

class RefinedTracingCR01_Descriptor extends SU_MenuDescriptor {
  public function build() {
    this.onHover('MasterEnabled', "", "tooltip_cr01_masterenabled");
    this.onHover('PTShadows', "", "tooltip_cr01_ptshadows");
    this.onHover('PTBillboards', "", "tooltip_cr01_ptbillboards");
    this.onHover('GeometryBounces', "", "tooltip_cr01_geometrybounces");
    this.onHover('HairBounces', "", "tooltip_cr01_hairbounces");
    this.onHover('IndirectLight', "", "tooltip_cr01_indirectlight");
    this.onHover('SunImpact', "", "tooltip_cr01_sunimpact");
    this.onHover('SkyImpact', "", "tooltip_cr01_skyimpact");
    this.onHover('AmbientOcclusion', "", "tooltip_cr01_ambientocclusion");
    this.onHover('AOStrength', "", "tooltip_cr01_aostrength");
    this.onHover('AORadius', "", "tooltip_cr01_aoradius");
    this.onHover('AOContrast', "", "tooltip_cr01_aocontrast");
    this.onHover('GrassDay', "", "tooltip_cr01_grassday");
    this.onHover('GrassNight', "", "tooltip_cr01_grassnight");
    this.onHover('SpecularScreenSpace', "", "tooltip_cr01_specularscreenspace");
    this.onHover('SpecularCheckerboard', "", "tooltip_cr01_specularcheckerboard");
    this.onHover('RayTracedOptimizations', "", "tooltip_cr01_rt_opt_title");
    this.onHover('RTPerfClassificationPrimary', "", "tooltip_cr01_rt_perf_primary");
    this.onHover('RTPerfClassificationSecondary', "", "tooltip_cr01_rt_perf_secondary");
    this.onHover('RTPerfMaxProbes', "", "tooltip_cr01_rt_perf_cap");
    this.onHover('RTPerfAOQuality', "", "tooltip_cr01_rt_perf_ao");
    this.onHover('RTPerfShadingBudget', "", "tooltip_cr01_rt_perf_budget");
    this.onHover('RTQualityClassificationPrimary', "", "tooltip_cr01_rt_quality_primary");
    this.onHover('RTQualityClassificationSecondary', "", "tooltip_cr01_rt_quality_secondary");
    this.onHover('RTQualityMaxProbes', "", "tooltip_cr01_rt_quality_cap");
    this.onHover('RTQualityAOQuality', "", "tooltip_cr01_rt_quality_ao");
    this.onHover('RTQualityShadingBudget', "", "tooltip_cr01_rt_quality_budget");
    this.withFallbackMessage("", "tooltip_cr01_fallback");
  }
}

@wrapMethod(CR4IngameMenu)
function SU_onMenuEntered(menu: string, out descriptors: array<SU_MenuDescriptor>) {
  wrappedMethod(menu, descriptors);
  if (menu == "refinedtracing") {
    descriptors.PushBack(new RefinedTracingCR01_Descriptor in this);
  }
}

@addMethod(CR4IngameMenu)
function RT_CR01_DisableDependents(masterDisabled: bool, rtDisabled: bool) {
  var tags: array<name>;
  var rtTags: array<name>;
  var changes: CScriptedFlashArray;
  var change: CScriptedFlashObject;
  var i: int;

  tags.PushBack('PTShadows');
  tags.PushBack('PTBillboards');
  tags.PushBack('GeometryBounces');
  tags.PushBack('HairBounces');
  tags.PushBack('IndirectLight');
  tags.PushBack('SunImpact');
  tags.PushBack('SkyImpact');
  tags.PushBack('AmbientOcclusion');
  tags.PushBack('AOStrength');
  tags.PushBack('AORadius');
  tags.PushBack('AOContrast');
  tags.PushBack('GrassDay');
  tags.PushBack('GrassNight');
  tags.PushBack('SpecularScreenSpace');
  tags.PushBack('SpecularCheckerboard');
  rtTags.PushBack('RTPerfClassificationPrimary');
  rtTags.PushBack('RTPerfClassificationSecondary');
  rtTags.PushBack('RTPerfMaxProbes');
  rtTags.PushBack('RTPerfAOQuality');
  rtTags.PushBack('RTPerfShadingBudget');
  rtTags.PushBack('RTQualityClassificationPrimary');
  rtTags.PushBack('RTQualityClassificationSecondary');
  rtTags.PushBack('RTQualityMaxProbes');
  rtTags.PushBack('RTQualityAOQuality');
  rtTags.PushBack('RTQualityShadingBudget');

  changes = m_flashValueStorage.CreateTempFlashArray();
  // Unchanged RC1 rule for all original fifteen controls.
  for (i = 0; i < tags.Size(); i += 1) {
    change = m_flashValueStorage.CreateTempFlashObject();
    change.SetMemberFlashUInt("tag", NameToFlashUInt(tags[i]));
    change.SetMemberFlashBool("disabled", masterDisabled);
    changes.PushBackFlashObject(change);
  }
  // Parent depends on Master; advanced rows depend on Master AND RT parent.
  change = m_flashValueStorage.CreateTempFlashObject();
  change.SetMemberFlashUInt("tag", NameToFlashUInt('RayTracedOptimizations'));
  change.SetMemberFlashBool("disabled", masterDisabled);
  changes.PushBackFlashObject(change);
  for (i = 0; i < rtTags.Size(); i += 1) {
    change = m_flashValueStorage.CreateTempFlashObject();
    change.SetMemberFlashUInt("tag", NameToFlashUInt(rtTags[i]));
    change.SetMemberFlashBool("disabled", masterDisabled || rtDisabled);
    changes.PushBackFlashObject(change);
  }
  m_flashValueStorage.SetFlashArray("options.update_disabled", changes);
  theGame.GetGuiManager().ForceProcessFlashStorage();
}

@addMethod(CR4IngameMenu)
function RT_CR01_IsDecimalText(raw: string): bool {
  var i: int;
  var dotCount: int;
  var c: string;
  if (StrLen(raw) == 0 || StrLen(raw) > 24) return false;
  dotCount = 0;
  for (i = 0; i < StrLen(raw); i += 1) {
    c = StrMid(raw, i, 1);
    if (c == ".") {
      dotCount += 1;
      if (dotCount > 1) return false;
    } else if (c != "0" && c != "1" && c != "2" && c != "3" && c != "4"
            && c != "5" && c != "6" && c != "7" && c != "8" && c != "9") {
      return false;
    }
  }
  if (StrLeft(raw, 1) == "." || StrRight(raw, 1) == ".") return false;
  return true;
}

@addMethod(CR4IngameMenu)
function RT_CR01_RepairLiveIndirectLight(): bool {
  var raw: string;
  var value: float;
  var corrected: string;
  raw = mInGameConfigWrapper.GetVarValue('RefinedTracingCR01', 'IndirectLight');
  if (this.RT_CR01_IsDecimalText(raw)) {
    value = StringToFloat(raw);
    if (value >= 1.0 && value <= 1.5) return false;
    if (value > 1.5) {
      corrected = "1.50";
    } else {
      corrected = "1.00";
    }
  } else {
    corrected = "1.00";
  }
  mInGameConfigWrapper.SetVarValue('RefinedTracingCR01', 'IndirectLight', corrected);
  theGame.SaveUserSettings();
  return true;
}

@wrapMethod(CR4IngameMenu)
function OnShowOptionSubmenu(actionType: int, menuTag: int, id: string) {
  var rawMaster: string;
  var rawRT: string;
  var repaired: bool;
  var corrected: string;
  var updates: CScriptedFlashArray;
  var update: CScriptedFlashObject;

  repaired = false;
  if (id == "refinedtracing") {
    repaired = this.RT_CR01_RepairLiveIndirectLight();
  }

  wrappedMethod(actionType, menuTag, id);

  if (id == "refinedtracing") {
    if (repaired) {
      corrected = mInGameConfigWrapper.GetVarValue('RefinedTracingCR01', 'IndirectLight');
      updates = m_flashValueStorage.CreateTempFlashArray();
      update = m_flashValueStorage.CreateTempFlashObject();
      update.SetMemberFlashUInt("tag", NameToFlashUInt('IndirectLight'));
      update.SetMemberFlashString("current", corrected);
      updates.PushBackFlashObject(update);
      m_flashValueStorage.SetFlashArray("options.force_update_values", updates);
      theGame.GetGuiManager().ForceProcessFlashStorage();
    }

    rawMaster = mInGameConfigWrapper.GetVarValue('RefinedTracingCR01', 'MasterEnabled');
    rawRT = mInGameConfigWrapper.GetVarValue('RefinedTracingCR01', 'RayTracedOptimizations');
    this.RT_CR01_DisableDependents(rawMaster != "true" && rawMaster != "1", rawRT != "true" && rawRT != "1");
  }
}

@wrapMethod(CR4IngameMenu)
function OnOptionValueChanged(groupId: int, optionName: name, optionValue: string) {
  var result: bool;
  var groupName: name;
  var rawMaster: string;
  var rawRT: string;

  result = wrappedMethod(groupId, optionName, optionValue);
  groupName = mInGameConfigWrapper.GetGroupName(groupId);

  if (groupName == 'RefinedTracingCR01') {
    if (optionName == 'MasterEnabled' || optionName == 'RayTracedOptimizations') {
      // The wrapped handler has already written the latest config values.
      rawMaster = mInGameConfigWrapper.GetVarValue('RefinedTracingCR01', 'MasterEnabled');
      rawRT = mInGameConfigWrapper.GetVarValue('RefinedTracingCR01', 'RayTracedOptimizations');
      this.RT_CR01_DisableDependents(rawMaster != "true" && rawMaster != "1", rawRT != "true" && rawRT != "1");
    }
    // Exact CR01 menu event -> durable menu mirror event for the native owner.
    theGame.SaveUserSettings();
  } else if (optionName == 'PTEnable' || optionName == 'EnableRT'
          || optionName == 'EnableRtRadiance' || optionName == 'Virtual_RTShadows') {
    // Renderer-eligibility/native-shadow changes use the same event path.
    // The ASI still verifies live CVars and never trusts this text as renderer truth.
    theGame.SaveUserSettings();
  }

  return result;
}
